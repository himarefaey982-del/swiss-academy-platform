'use strict';
// Swiss Academy server — بدون أي مكتبات خارجية (Node 18+)
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=+process.env.PORT||3000,DATA=process.env.DATA_DIR||path.join(__dirname,'data');
const FILE=path.join(DATA,'state.json'),BK=path.join(DATA,'backups');
fs.mkdirSync(BK,{recursive:true});
const hashPw=p=>{const s=crypto.randomBytes(16);return s.toString('hex')+':'+crypto.scryptSync(p,s,64).toString('hex')};
const checkPw=(p,h)=>{const [s,k]=h.split(':');return crypto.timingSafeEqual(crypto.scryptSync(p,Buffer.from(s,'hex'),64),Buffer.from(k,'hex'))};
const DUMMY=hashPw('dummy');
const norm=s=>String(s||'').normalize('NFKC').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه').replace(/\s+/g,' ').trim().toLowerCase();
function persistNow(){const t=FILE+'.tmp';fs.writeFileSync(t,JSON.stringify(state));fs.renameSync(t,FILE);
 const b=path.join(BK,'state-'+new Date().toISOString().slice(0,10)+'.json');if(!fs.existsSync(b))fs.copyFileSync(FILE,b);
 fs.readdirSync(BK).sort().slice(0,-30).forEach(f=>fs.unlinkSync(path.join(BK,f)))}
let timer=null;const persist=()=>{clearTimeout(timer);timer=setTimeout(persistNow,300)};
let state;
if(fs.existsSync(FILE))state=JSON.parse(fs.readFileSync(FILE,'utf8'));
else{state=JSON.parse(fs.readFileSync(path.join(__dirname,'seed.json'),'utf8'));
 const pw=process.env.ADMIN_PASSWORD||crypto.randomBytes(9).toString('base64url');
 state.accounts=[{id:1,name:'مدير النظام',username:'admin',role:'manager',active:true,hash:hashPw(pw)}];state.complaints=[];
 state.portalReports=[];state.resources=[];persistNow();
 console.log('\n*** أول تشغيل — دخول المدير: admin /',pw,'— غيّر كلمة المرور بعد الدخول ***\n')}
for(const k of ['portalReports','resources','complaints'])if(!state[k])state[k]=[];
// حسابات أولية (مرة واحدة فقط): تتضاف لو مش موجودة، ولو اتحذفت بعد كده مبترجعش
try{const f=path.join(__dirname,'initial_accounts.json');if(fs.existsSync(f)){const sf=path.join(DATA,'seeded.json');
 const done=fs.existsSync(sf)?JSON.parse(fs.readFileSync(sf,'utf8')):[];let ch=false,th=null;
 for(const x of JSON.parse(fs.readFileSync(f,'utf8'))){const k=norm(x.username);if(done.includes(k))continue;done.push(k);ch=true;
  if(state.accounts.some(a=>norm(a.username)===k))continue;th=th||hashPw('123456');
  state.accounts.push({id:Math.max(0,...state.accounts.map(a=>a.id))+1,name:x.name,username:x.username,role:x.role,active:true,hash:th,mustChange:true});
  console.log('تم إنشاء حساب:',x.username,'(كلمة المرور المؤقتة 123456)')}
 if(ch){fs.writeFileSync(sf,JSON.stringify(done));persistNow()}}}catch(e){console.error('initial accounts:',e.message)}
const sessions=new Map(),fails=new Map();
const pub=a=>{const {hash,password,...r}=a;return r};
function auth(req){const m=/(?:^|; )sid=([a-f0-9]{64})/.exec(req.headers.cookie||'');if(!m)return null;
 const s=sessions.get(m[1]);if(!s||s.exp<Date.now()){sessions.delete(m[1]);return null}
 const a=state.accounts.find(x=>x.id===s.id&&x.active!==false);return a?{a,tok:m[1]}:null}
function forParent(a){const ids=new Set((a.studentIds||[]).map(String));
 const students=state.students.filter(s=>ids.has(String(s.id))),grades=new Set(students.map(s=>s.grade));
 const att={};for(const [k,d] of Object.entries(state.att||{})){if(!grades.has(k.split('|')[1]))continue;const o={};for(const id of ids)if(d[id]!==undefined)o[id]=d[id];if(Object.keys(o).length)att[k]=o}
 return {curr:state.curr,teachers:[],assign:{},students,att,nextId:state.nextId,
  schedule:(state.schedule||[]).filter(x=>grades.has(x.grade)),homework:(state.homework||[]).filter(h=>grades.has(h.grade)),
  portalReports:(state.portalReports||[]).filter(r=>ids.has(String(r.studentId))||(!r.studentId&&grades.has(r.grade))),
  complaints:(state.complaints||[]).filter(c=>c.accountId===a.id).map(({id,date,student,text,status,reply})=>({id,date,student,text,status,reply:reply||''})),
  resources:(state.resources||[]).filter(r=>ids.has(String(r.studentId))||(!r.studentId&&(!r.grade||grades.has(r.grade))))}}
function stateFor(a){if(a.role==='parent')return forParent(a);
 const {accounts,complaints,...rest}=state;if(a.role==='manager')return {...rest,complaints,accounts:accounts.map(pub)};return {...rest,students:rest.students.map(({fee,paid,...r})=>r)}}
const WRITE={manager:null,secretary:['att','portalReports','resources','nextId'],teacher:['att','homework','schedule','portalReports','resources','nextId']};
function put(s,key,val){const w=WRITE[s.a.role];if(w===undefined)return [403,'ممنوع'];
 if(!Object.hasOwn(state,key)||(w&&!w.includes(key)))return [403,'ممنوع'];
 if(Array.isArray(val)!==Array.isArray(state[key])||typeof val!==typeof state[key]||val===null)return [400,'بيانات غير صالحة'];
 if(key==='complaints'){const ids=new Set(val.map(c=>c&&c.id));state.complaints=[...val,...state.complaints.filter(c=>!ids.has(c.id))];persist();return [200,{ok:1}]}
 if(key==='nextId'){state.nextId=Math.max(state.nextId,val);persist();return [200,{ok:1}]}
 if(key==='att'){state.att={...state.att,...val};persist();return [200,{ok:1,value:state.att}]}
 if(key==='accounts'){const old=state.accounts,out=[],seen=new Set();
  for(const x of val){if(!x||typeof x!=='object')return [400,'بيانات غير صالحة'];
   const un=String(x.username||'').trim(),nu=norm(un);if(!un||seen.has(nu))return [400,'اسم مستخدم مكرر'];seen.add(nu);
   if(!['manager','secretary','teacher','parent'].includes(x.role))return [400,'فئة غير صالحة'];
   const ex=old.find(o=>o.id===x.id);let hash=ex&&ex.hash,must=ex?!!ex.mustChange:true;
   if(x.password){if(String(x.password).length<6)return [400,'كلمة المرور قصيرة'];hash=hashPw(String(x.password));must=x.id!==s.a.id}
   if(!hash)return [400,'الحساب بدون كلمة مرور'];
   const {password,...r}=x;out.push({...r,username:un,hash,mustChange:must})}
  if(!out.some(o=>o.role==='manager'&&o.active!==false))return [400,'لازم يفضل مدير واحد نشط'];
  for(const [t,ss] of sessions)if(t!==s.tok){const o=out.find(x=>x.id===ss.id),e=old.find(x=>x.id===ss.id);if(o&&e&&o.hash!==e.hash)sessions.delete(t)}
  state.accounts=out;persist();return [200,{ok:1}]}
 state[key]=val;persist();return [200,{ok:1}]}
const body=(req,max)=>new Promise((res,rej)=>{let n=0;const c=[];req.on('data',d=>{n+=d.length;if(n>max){rej(new Error('big'));req.destroy()}else c.push(d)});req.on('end',()=>res(Buffer.concat(c).toString()));req.on('error',rej)});
const HDR={'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Cache-Control':'no-store',
 'Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"};
const send=(res,code,obj,extra={})=>{const j=typeof obj==='string';res.writeHead(code,{...HDR,'Content-Type':j?'text/plain; charset=utf-8':'application/json',...extra});res.end(j?obj:JSON.stringify(obj))};
const ipOf=req=>process.env.TRUST_PROXY?String(req.headers['x-forwarded-for']||'').split(',')[0].trim()||req.socket.remoteAddress:req.socket.remoteAddress;
http.createServer(async(req,res)=>{try{
 const url=req.url.split('?')[0];
 if(req.method==='GET'&&(url==='/'||url==='/index.html')){res.writeHead(200,{...HDR,'Content-Type':'text/html; charset=utf-8'});return res.end(fs.readFileSync(path.join(__dirname,'public','index.html')))}
 const ST={'/manifest.webmanifest':'application/manifest+json','/sw.js':'text/javascript','/icon-192.png':'image/png','/icon-512.png':'image/png','/maskable-512.png':'image/png','/apple-touch-icon.png':'image/png'};
 if(req.method==='GET'&&Object.hasOwn(ST,url)){res.writeHead(200,{...HDR,'Content-Type':ST[url],'Cache-Control':url==='/sw.js'?'no-cache':'public, max-age=3600'});return res.end(fs.readFileSync(path.join(__dirname,'public',url.slice(1))))}
 if(!url.startsWith('/api/'))return send(res,404,'غير موجود');
 if(req.method!=='GET'){if(!/json/.test(req.headers['content-type']||''))return send(res,415,'JSON only');
  if(req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)return send(res,403,'origin')}
 if(req.method==='POST'&&url==='/api/login'){
  const {username,password}=JSON.parse(await body(req,1e4)),u=norm(username),k=ipOf(req)+'|'+u,f=fails.get(k);
  if(f&&f.n>=8&&f.t>Date.now())return send(res,429,'محاولات كتير');
  const a=state.accounts.find(x=>norm(x.username)===u),ok=checkPw(String(password||''),a?a.hash:DUMMY)&&a&&a.active!==false;
  if(!ok){if(!f||f.t<Date.now())fails.set(k,{n:1,t:Date.now()+9e5});else f.n++;return send(res,401,'بيانات غير صحيحة')}
  fails.delete(k);const tok=crypto.randomBytes(32).toString('hex');sessions.set(tok,{id:a.id,exp:Date.now()+12*36e5});
  const sec=(req.socket.encrypted||req.headers['x-forwarded-proto']==='https')?'; Secure':'';
  return send(res,200,pub(a),{'Set-Cookie':`sid=${tok}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200${sec}`})}
 const s=auth(req);
 if(req.method==='POST'&&url==='/api/logout'){if(s)sessions.delete(s.tok);return send(res,200,{ok:1},{'Set-Cookie':'sid=; HttpOnly; Path=/; Max-Age=0'})}
 if(!s)return send(res,401,'سجّل الدخول');
 if(req.method==='POST'&&url==='/api/change-password'){const {oldPassword,newPassword}=JSON.parse(await body(req,1e4)),np=String(newPassword||'');
  if(!checkPw(String(oldPassword||''),s.a.hash))return send(res,401,'كلمة المرور الحالية غير صحيحة');
  if(np.length<6||np==='123456'||np===String(oldPassword))return send(res,400,'كلمة المرور الجديدة لازم تكون 6 أحرف على الأقل وتختلف عن المؤقتة');
  s.a.hash=hashPw(np);s.a.mustChange=false;for(const [t,ss] of sessions)if(ss.id===s.a.id&&t!==s.tok)sessions.delete(t);persist();return send(res,200,pub(s.a))}
 if(s.a.mustChange)return send(res,403,{mustChange:true});
 if(req.method==='POST'&&url==='/api/complaints'){if(s.a.role!=='parent')return send(res,403,'ممنوع');
  const {text,studentId}=JSON.parse(await body(req,1e5)),t=String(text||'').trim().slice(0,2000);if(!t)return send(res,400,'اكتب نص الشكوى');
  const day=new Date().toISOString().slice(0,10);
  if(state.complaints.filter(c=>c.accountId===s.a.id&&c.date===day).length>=5)return send(res,429,'وصلت للحد اليومي للشكاوي (5)');
  const ids=(s.a.studentIds||[]).map(String);let sid=String(studentId||'');if(!ids.includes(sid))sid=ids.length===1?ids[0]:'';
  const st=state.students.find(x=>String(x.id)===sid);let id=Date.now();while(state.complaints.some(c=>c.id===id))id++;
  state.complaints.push({id,date:day,parent:s.a.name,phone:(st&&st.phone)||'',student:st?st.name:'',grade:st?st.grade:'',text:t,status:'جديدة',notes:[],reply:'',accountId:s.a.id});
  persist();return send(res,200,{complaints:forParent(s.a).complaints})}
 if(req.method==='POST'&&url==='/api/accounts/bulk'){if(s.a.role!=='manager')return send(res,403,'ممنوع');
  const {kind}=JSON.parse(await body(req,1e4));if(kind!=='parents'&&kind!=='teachers')return send(res,400,'bad');
  const used=new Set(state.accounts.map(a=>norm(a.username))),th=hashPw('123456'),created=[];let id=Math.max(0,...state.accounts.map(a=>a.id))+1;
  const two=n=>String(n||'').trim().split(/\s+/).slice(0,2).join(' ');
  const uniq=b=>{let u=b,i=2;while(used.has(norm(u)))u=b+' '+i++;used.add(norm(u));return u};
  if(kind==='parents'){const linked=new Set(state.accounts.filter(a=>a.role==='parent').flatMap(a=>(a.studentIds||[]).map(String)));
   for(const st of state.students){if(linked.has(String(st.id)))continue;const un=uniq(two(st.name));
    state.accounts.push({id:id++,name:'ولي أمر '+st.name,username:un,role:'parent',active:true,studentIds:[st.id],hash:th,mustChange:true});
    created.push({name:st.name,grade:st.grade,username:un,password:'123456',role:'parent'})}}
  else{const linked=new Set(state.accounts.filter(a=>a.role==='teacher').map(a=>String(a.teacherId)));
   for(const t of state.teachers){if(linked.has(String(t.id)))continue;const un=uniq(two(t.name));
    state.accounts.push({id:id++,name:t.name,username:un,role:'teacher',active:true,teacherId:t.id,hash:th,mustChange:true});
    created.push({name:t.name,grade:'',username:un,password:'123456',role:'teacher'})}}
  persist();return send(res,200,{created})}
 if(req.method==='GET'&&url==='/api/state')return send(res,200,stateFor(s.a));
 if(req.method==='GET'&&url==='/api/backup'){if(s.a.role!=='manager')return send(res,403,'ممنوع');return send(res,200,JSON.stringify(state),{'Content-Type':'application/json','Content-Disposition':'attachment; filename="swiss-academy-backup.json"'})}
 const m=/^\/api\/state\/(\w+)$/.exec(url);
 if(req.method==='PUT'&&m){const [c,o]=put(s,m[1],JSON.parse(await body(req,25e6)));return send(res,c,o)}
 send(res,404,'غير موجود')}catch(e){send(res,400,'طلب غير صالح')}}).listen(PORT,()=>console.log('Swiss Academy on :'+PORT));
setInterval(()=>{const n=Date.now();for(const [t,s] of sessions)if(s.exp<n)sessions.delete(t)},36e5);
process.on('SIGTERM',()=>{persistNow();process.exit(0)});
