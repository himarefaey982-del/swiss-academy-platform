// لا يخزّن أي بيانات (الحسابات والبيانات خاصة). بس بيخلّي التطبيق قابل للتثبيت ويعرض رسالة لو مفيش إنترنت.
self.addEventListener("install",()=>self.skipWaiting());
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>{if(e.request.mode==="navigate")e.respondWith(fetch(e.request).catch(()=>new Response('<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;text-align:center;padding:48px 20px"><h2>لا يوجد اتصال بالإنترنت</h2><p>افتح التطبيق تاني لما الإنترنت يرجع.</p></body>',{headers:{"Content-Type":"text/html; charset=utf-8"}})))});
